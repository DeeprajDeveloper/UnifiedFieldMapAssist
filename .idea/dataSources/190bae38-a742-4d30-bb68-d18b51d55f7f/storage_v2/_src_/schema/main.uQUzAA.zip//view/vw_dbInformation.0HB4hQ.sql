CREATE VIEW vw_dbInformation AS
SELECT 
	ai.guiId [id]
	, db.tableName
	, db.columnName
	, db.columnSize
	, dt.dataTypDesc
FROM databaseInformation db
left join apiInformation ai on ai.id = db.apiId
left join dataType dt on dt.dataTypId = db.dataTypeId
where ai.RecordStatus = 1;


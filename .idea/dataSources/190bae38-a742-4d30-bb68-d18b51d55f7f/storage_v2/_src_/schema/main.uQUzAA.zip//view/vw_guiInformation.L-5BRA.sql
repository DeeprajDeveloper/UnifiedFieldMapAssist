CREATE VIEW vw_guiInformation AS
SELECT 
	gi.id
	, gi.screenName
	, gi.sectionName
	, gi.fieldName
	, gi.fieldDescription
	, fs.fieldStateDesc
	, gft.uiTypDesc
	, gi.dependencyId 
FROM guiInformation gi 
left join fieldState fs on fs.fieldStateId = gi.fieldStateId
left join guiFieldType gft on gft.uiTypId = gi.uiTypId
where gi.RecordStatus = 1;


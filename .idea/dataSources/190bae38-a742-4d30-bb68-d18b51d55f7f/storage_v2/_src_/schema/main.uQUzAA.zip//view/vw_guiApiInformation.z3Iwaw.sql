CREATE VIEW vw_guiApiInformation AS
SELECT 
	gi.id
	, gi.screenName
	, gi.sectionName
	, gi.fieldName
	, gi.fieldDescription
	, fs.fieldStateDesc
	, gft.uiTypDesc
	, gi.dependencyId
	, ai.entityName
	, ai.domainName
	, ai.subdomainName
	, ai.childDomainLvl1
	, ai.childDomainLvl2
	, ai.businessFieldName
	, dt.dataTypDesc
FROM guiInformation gi 
left join apiInformation ai on ai.guiId = gi.id
left join fieldState fs on fs.fieldStateId = gi.fieldStateId
left join guiFieldType gft on gft.uiTypId = gi.uiTypId
left join dataType dt on dt.dataTypId = ai.dataTypeId
where gi.RecordStatus = 1;

